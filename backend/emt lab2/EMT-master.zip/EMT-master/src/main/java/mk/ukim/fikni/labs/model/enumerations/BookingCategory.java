package mk.ukim.fikni.labs.model.enumerations;

public enum BookingCategory {
    ROOM, HOUSE, FLAT, APARTMENT, HOTEL, MOTEL
}
