package mk.ukim.fikni.labs.service;

import mk.ukim.fikni.labs.dto.BookingDTO;
import mk.ukim.fikni.labs.model.Booking;

import java.util.List;
import java.util.Optional;

public interface BookingService {

    List<Booking> findAll();
    Optional<Booking> findById(Long id);
    Optional<Booking> update(Long id, BookingDTO booking);

    Optional<Booking> save(BookingDTO booking);

    void deleteById(Long id);

    Optional<Booking> availableBooking(Long bookingID);
}
