package mk.ukim.fikni.labs.service.impl;


import mk.ukim.fikni.labs.dto.BookingDTO;
import mk.ukim.fikni.labs.model.Booking;
import mk.ukim.fikni.labs.repository.BookingRepository;
import mk.ukim.fikni.labs.repository.HostRepository;
import mk.ukim.fikni.labs.service.BookingService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingServiceImpl implements BookingService {
    private final BookingRepository bookingRepository;
    private final HostRepository hostRepository;

    public BookingServiceImpl(BookingRepository bookingRepository, HostRepository hostRepository) {
        this.bookingRepository = bookingRepository;
        this.hostRepository = hostRepository;
    }

    @Override
    public List<Booking> findAll() {
        return bookingRepository.findAll();
    }

    @Override
    public Optional<Booking> findById(Long id) {
        return bookingRepository.findById(id);
    }

    @Override
    public Optional<Booking> update(Long id, BookingDTO booking) {
        return bookingRepository.findById(id).map(existingProduct -> {
            if (booking.getName() != null) {
                existingProduct.setName(booking.getName());
            }
            if (booking.getCategory() != null) {
                existingProduct.setCategory(booking.getCategory());
            }
            if (booking.getHostID() != null && hostRepository.findById(booking.getHostID()).isPresent()) {
                existingProduct.setHost(hostRepository.findById(booking.getHostID()).get());
            }
            if (booking.getNumOfRooms() != null) {
                existingProduct.setNumRooms(booking.getNumOfRooms());
            }
            return bookingRepository.save(existingProduct);
        });
    }


    //vo if samo za vrskite proverva
    @Override
    public Optional<Booking> save(BookingDTO booking) {
        if (booking.getHostID() !=null && hostRepository.findById(booking.getHostID()).isPresent())
            return Optional.of(bookingRepository.save(new Booking(booking.getName(), booking.getCategory(), hostRepository.findById(booking.getHostID()).get(), booking.getNumOfRooms())));
        return Optional.empty();
    }

    @Override
    public void deleteById(Long id) {
        bookingRepository.deleteById(id);
    }


    // obelezhi kako iznajmeno
    @Override
    public Optional<Booking> availableBooking(Long bookingID) {
        return bookingRepository.findById(bookingID).map(booking -> {
            if (booking.getNumRooms() > 0) {
                booking.setNumRooms(booking.getNumRooms() - 1);
                bookingRepository.save(booking);
                return booking;
            } else {
                throw new IllegalStateException("No available rooms for this housing.");
            }
        });
    }

}
