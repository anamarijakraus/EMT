package mk.ukim.fikni.labs.dto;

import lombok.Data;
import mk.ukim.fikni.labs.model.enumerations.BookingCategory;

@Data
public class BookingDTO {

    private String name;

    private BookingCategory category;

    private Long hostID;

    private Integer numOfRooms;

    public BookingDTO() {
    }

    public BookingDTO(String name, BookingCategory category, Long hostID, int numOfRooms) {
        this.name = name;
        this.category = category;
        this.hostID = hostID;
        this.numOfRooms = numOfRooms;
    }
}
