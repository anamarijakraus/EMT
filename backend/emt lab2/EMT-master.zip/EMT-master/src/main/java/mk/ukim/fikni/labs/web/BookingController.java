package mk.ukim.fikni.labs.web;


import mk.ukim.fikni.labs.dto.BookingDTO;
import mk.ukim.fikni.labs.model.Booking;
import mk.ukim.fikni.labs.service.BookingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @GetMapping
    public List<Booking> findAll() {
        return bookingService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> findById(@PathVariable Long id) {
        return bookingService.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }


    @PutMapping("/edit/{id}")
    public ResponseEntity<Booking> update(@PathVariable Long id, @RequestBody BookingDTO booking) {
        return bookingService.update(id, booking)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/add")
    public ResponseEntity<Booking> save(@RequestBody BookingDTO booking) {
        return bookingService.save(booking)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (bookingService.findById(id).isPresent()) {
            bookingService.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PatchMapping("/{id}/rent")
    public ResponseEntity<?> rent(@PathVariable Long id) {
        try {
            Booking bookedHousing = bookingService.availableBooking(id).orElseThrow();
            return ResponseEntity.ok(bookedHousing);
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage()); // Return 400 with error message
        }
    }


}
