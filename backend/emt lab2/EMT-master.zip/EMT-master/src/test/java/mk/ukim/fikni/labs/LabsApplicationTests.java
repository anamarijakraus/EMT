package mk.ukim.fikni.labs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabsApplicationTests {

	@Test
	void contextLoads() {
	}

}
